// ===== API Settings =====
// Run your database with: json-server --watch db.json --port 3002
var API_URLS = ["http://localhost:3002"];

function apiGet(path) {
  return fetch(API_URLS[0] + path)
    .catch(function () {
      return fetch(API_URLS[1] + path);
    })
    .then(function (response) {
      if (!response.ok) {
        throw new Error("API error: " + response.status);
      }
      return response.json();
    });
}

function apiPost(path, data) {
  return fetch(API_URLS[0] + path, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(data)
  })
    .catch(function () {
      return fetch(API_URLS[1] + path, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
      });
    })
    .then(function (response) {
      if (!response.ok) {
        throw new Error("API error: " + response.status);
      }
      return response.json();
    });
}

// ===== Button Click (index.html) =====
function changeText() {
  var demo = document.getElementById("demo");
  if (demo) {
    demo.innerText = "Text changed successfully!";
  }
}

function goToRegister() {
  window.location.href = "register.html";
}

// ===== Form Validation (contact.html) =====
function validateForm() {
  var name = document.getElementById("name").value;
  var email = document.getElementById("email").value;
  var message = document.getElementById("message");
  var valid = true;
  var namePattern = /^[A-Za-z\s]+$/;

  if (name === "") {
    document.getElementById("nameError").innerText = "Name is required";
    valid = false;
  } else if (!namePattern.test(name)) {
    document.getElementById("nameError").innerText = "Name must contain only letters";
    valid = false;
  } else {
    document.getElementById("nameError").innerText = "";
  }

  if (email === "") {
    document.getElementById("emailError").innerText = "Email is required";
    valid = false;
  } else {
    document.getElementById("emailError").innerText = "";
  }

  if (message && message.value === "") {
    document.getElementById("messageError").innerText = "Message is required";
    valid = false;
  } else if (document.getElementById("messageError")) {
    document.getElementById("messageError").innerText = "";
  }

  if (valid) {
    alert("Message sent successfully!");
  }

  return valid;
}

// ===== Live input blocking for name field (contact.html) =====
var nameField = document.getElementById("name");
if (nameField) {
  nameField.addEventListener("input", function () {
    this.value = this.value.replace(/[^A-Za-z\s]/g, "");
  });
}

// ===== Fetch Courses from db.json API (products.html) =====
var coursesContainer = document.getElementById("courses");

if (coursesContainer) {
  apiGet("/products")
    .then(function (data) {
      var products = Array.isArray(data) ? data : data.products;
      coursesContainer.innerHTML = "";

      if (!products || products.length === 0) {
        coursesContainer.innerHTML = "<p>No courses found.</p>";
        return;
      }

      products.forEach(function (product) {
        var div = document.createElement("div");
        div.className = "course-card";

        div.innerHTML =

  '<div class="course-top">' +

    '<div>' +
      '<h3>' + product.name + '</h3>' +
    '</div>' +

    '<div class="course-price">$' + product.price + '</div>' +

  '</div>' +

  '<div class="course-info">' +

    '<p><strong>Description:</strong> ' +
    product.description + '</p>' +

    '<p><strong>Duration:</strong> ' +
    product.duration_hours + ' hours</p>' +

    '<p><strong>Instructor:</strong> ' +
    product.instructor.name + '</p>' +

    '<p><strong>Rating:</strong> ⭐ ' +
    product.rating + '</p>' +

  '</div>' +

  '<button class="select-btn">Select →</button>';

        coursesContainer.appendChild(div);

        var button = div.querySelector(".select-btn");

        button.addEventListener("click", function () {

  var currentUser =
    localStorage.getItem("userEmail");

  apiGet("/selectedCourses")
    .then(function(courses) {

      var alreadySelected = courses.some(function(course) {

        return (
          course.courseId === product.id &&
          course.userEmail === currentUser
        );

      });

      if (alreadySelected) {

        alert("Course already selected!");

        return;
      }

      var selectedCourseData = {

        courseId: product.id,
        userEmail: currentUser,
        name: product.name,
        price: product.price,
        instructor: product.instructor.name

      };

      apiPost("/selectedCourses", selectedCourseData)

        .then(function() {

          alert("Course selected successfully ✅");

        });

    });

});

      });
    })
    .catch(function (error) {
      console.log(error);
      coursesContainer.innerHTML =
        '<p style="color:red;">Failed to load courses. Run: json-server --watch db.json --port 3002</p>';
    });
}

// ===== Register Form Validation + POST to db.json =====
function getRegisterData() {
  var name = document.getElementById("registerName").value.trim();
  var email = document.getElementById("registerEmail").value.trim();
  var password = document.getElementById("registerPassword").value;
  var valid = true;
  var namePattern = /^[A-Za-z\s]+$/;

  if (name === "") {
    document.getElementById("registerNameError").innerText = "Name is required";
    valid = false;
  } else if (!namePattern.test(name)) {
    document.getElementById("registerNameError").innerText = "Name must contain only letters";
    valid = false;
  } else {
    document.getElementById("registerNameError").innerText = "";
  }

  if (email === "") {
    document.getElementById("registerEmailError").innerText = "Email is required";
    valid = false;
  } else {
    document.getElementById("registerEmailError").innerText = "";
  }

  if (password === "") {
    document.getElementById("registerPasswordError").innerText = "Password is required";
    valid = false;
  } else if (password.length < 6) {
    document.getElementById("registerPasswordError").innerText = "Password must be at least 6 characters";
    valid = false;
  } else {
    document.getElementById("registerPasswordError").innerText = "";
  }

  if (!valid) {
    return null;
  }

  return {
    name: name,
    email: email,
    password: password
  };
}

function registerForm() {
  var userData = getRegisterData();

  if (!userData) {
    return false;
  }

  apiPost("/users", userData)
    .then(function () {
      localStorage.setItem("userName", userData.name);
      localStorage.setItem("userEmail", userData.email);
      alert("Registration successful");
      window.location.href = "login-in.html";
    })
    .catch(function (error) {
      console.log(error);
      alert("Registration failed. Run: json-server --watch db.json --port 3002");
    });

  return false;
}

var registerFormElement = document.getElementById("registerForm");
if (registerFormElement) {
  registerFormElement.addEventListener("submit", function (e) {
    e.preventDefault();
    registerForm();
  });
}

// ===== Login Form GET from db.json =====
function loginForm() {
  var email = document.getElementById("loginEmail").value.trim();
  var password = document.getElementById("loginPassword").value;
  var valid = true;

  if (email === "") {
    document.getElementById("loginEmailError").innerText = "Email is required";
    valid = false;
  } else {
    document.getElementById("loginEmailError").innerText = "";
  }

  if (password === "") {
    document.getElementById("loginPasswordError").innerText = "Password is required";
    valid = false;
  } else {
    document.getElementById("loginPasswordError").innerText = "";
  }

  if (!valid) {
    return false;
  }

  apiGet("/users")
    .then(function (users) {
      var foundUser = users.find(function (user) {
        return user.email === email && user.password === password;
      });

      if (foundUser) {
        localStorage.setItem("userName", foundUser.name);
        localStorage.setItem("userEmail", foundUser.email);
        alert("Login successful!");
        window.location.href = "products.html";
      } else {
        alert("Wrong email or password");
      }
    })
    .catch(function (error) {
      console.log(error);
      alert("Login failed. Run: json-server --watch db.json --port 3002");
    });

  return false;
}

// ===== My Profile Page =====
var profileName = document.getElementById("profileName");
var profileEmail = document.getElementById("profileEmail");
var profilePhone = document.getElementById("profilePhone");
var profilePhoto = document.getElementById("profilePhoto");
var photoInput = document.getElementById("photoInput");

if (profileName) {
  profileName.textContent = localStorage.getItem("userName") || "Not saved";
}

if (profileEmail) {
  profileEmail.textContent = localStorage.getItem("userEmail") || "Not saved";
}

if (profilePhone) {
  profilePhone.value = localStorage.getItem("userPhone") || "";

  profilePhone.addEventListener("input", function () {
    profilePhone.value = profilePhone.value.replace(/[^0-9]/g, "");
    localStorage.setItem("userPhone", profilePhone.value);
  });

  profilePhone.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      localStorage.setItem("userPhone", profilePhone.value);
      alert("Phone saved successfully!");
    }
  });
}

if (profilePhoto) {
  var savedPhoto = localStorage.getItem("profilePhoto");
  if (savedPhoto) {
    profilePhoto.src = savedPhoto;
  }
}

if (photoInput && profilePhoto) {
  photoInput.addEventListener("change", function () {
    var file = photoInput.files[0];

    if (file) {
      var reader = new FileReader();

      reader.onload = function (e) {
        profilePhoto.src = e.target.result;
        localStorage.setItem("profilePhoto", e.target.result);
      };

      reader.readAsDataURL(file);
    }
  });
}
// ===== Show Selected Courses in My Profile =====

var selectedCoursesDiv =
  document.getElementById("selectedCourses");

if (selectedCoursesDiv) {

  var currentUser =
    localStorage.getItem("userEmail");

  apiGet("/selectedCourses")
    .then(function(selectedCourses) {

      selectedCoursesDiv.innerHTML = "";

      var userCourses = selectedCourses.filter(function(course) {
        return course.userEmail === currentUser;
      });

      if (userCourses.length === 0) {

        selectedCoursesDiv.innerHTML =
          "<p>No courses selected yet.</p>";

      } else {

        userCourses.forEach(function(course) {

          var div = document.createElement("div");

          div.innerHTML =
            "<h3>" + course.name + "</h3>" +
            "<p><strong>Price:</strong> $" + course.price + "</p>" +
            "<p><strong>Instructor:</strong> " + course.instructor + "</p>" +
            "<hr>";

          selectedCoursesDiv.appendChild(div);

        });

      }

    });

}